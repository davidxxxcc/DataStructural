package SparseMatrix.copy;

import java.awt.Frame;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.Inet4Address;
import java.util.Arrays;
import java.util.Scanner;
import java.util.PrimitiveIterator.OfDouble;
import javax.swing.tree.ExpandVetoException;

public class MatrixTest {

	private static Scanner scanner = new Scanner(System.in);
	private static SparseMatrix[] mArray = new SparseMatrix [10];
	private static int itemCount = 0;
	private static int newItem = 0;
	private static String fileName;
	public static void main(String[] args) throws IOException {
		String option = "1";
		System.out.print("�п�J�ɮצW��: ");
		fileName = scanner.next();
		readFile(fileName);	//Read txt file and write into sparseMatrix object
		boolean run = true;
		SparseMatrix.Term aTerm = new SparseMatrix.Term();
		while(run) {
			System.out.print("1) Clone, 2) Transpose, 3) Add, 4) Mult, 5) Save, 6) Exit ");
			option = scanner.next();
			switch(option) {
			case "1" :
				cloneMatrix();
				System.out.println("�x�}�w�s�J�}�C���� ��m�� " + (itemCount -1));
				break;
			case "2" :
				transposeMatrix();
				System.out.println("�x�}�w�s�J�}�C���� ��m�� " + (itemCount -1));
				break;
			case "3" :
				addMatrix();
				System.out.println("�x�}�w�s�J�}�C���� ��m�� " + (itemCount -1));
				break;
			case "4" :
				multMatrix();
				System.out.println("�x�}�w�s�J�}�C���� ��m�� " + (itemCount -1));
				break;
			case "5" :
				saveMatrix();
				System.out.println("�ɮ׷s�W���\!");
				break;
			case "6" :
				run = false;
				break;
			default :
				System.out.println("��J���~! ");
				break;
			}
		}
	}
	
	public static void saveMatrix() throws IOException {
		System.out.print("�п�J�ɦW(��Jo�g�^���ɮ�): ");
		String name = scanner.next();
		//�g�^�쥻���ɮ�
		if (name.equals("o")) {
			name = fileName;
			//�p�G���s�W�x�}
			if (itemCount > 0 && itemCount > newItem){
				for (int i = newItem; i < itemCount; i++) {
					mArray[i].writeMatrix(name);
				}
			}
		}
		//�t�s�s�ɮ�0
		else {
			for (int i = 0; i < itemCount; i++) {
				mArray[i].writeMatrix(name);
			}
		}
	}
	
	public static void multMatrix() {
		while(true) {
			System.out.print("Index: ");
			String indexS1 = scanner.next();
			String indexS2 = scanner.next();
			try {
				int index1 = Integer.parseInt(indexS1);
				int index2 = Integer.parseInt(indexS2);
				
				if (index2 < 0 || index1 < 0 || index1 >= itemCount || index2 >= itemCount) {
					System.out.println("Index��J���~!");
				}
				else {
					int row1 = mArray[index1].getTerms()[0].row;
					int col1 = mArray[index1].getTerms()[0].col;
					int row2 = mArray[index2].getTerms()[0].row;
					int col2 = mArray[index2].getTerms()[0].col;
					if (row1 != row2 || col1 != col2) {
						System.out.println("Index��J���~! �x�}�j�p���P");
					}
					else {
						mArray[itemCount] = SparseMatrix.mult(mArray[index1],mArray[index2]);
						mArray[itemCount++].show();
						break;
					}
				}
			}catch(Exception e) {
				System.out.println("�п�J�Ʀr! ");
			}
			scanner.nextLine();
		}
	}
	
	public static void addMatrix() {
		while(true) {
			System.out.print("Index: ");
			String indexS1 = scanner.next();
			String indexS2 = scanner.next();
			try {
				int index1 = Integer.parseInt(indexS1);
				int index2 = Integer.parseInt(indexS2);
				
				if (index2 < 0 || index1 < 0 || index1 >= itemCount || index2 >= itemCount) {
					System.out.println("Index��J���~!");
				}
				else {
					int row1 = mArray[index1].getTerms()[0].row;
					int col1 = mArray[index1].getTerms()[0].col;
					int row2 = mArray[index2].getTerms()[0].row;
					int col2 = mArray[index2].getTerms()[0].col;
					if (row1 != row2 || col1 != col2) {
						System.out.println("Index��J���~! �x�}�j�p���P");
					}
					else {
						mArray[itemCount] = SparseMatrix.mult(mArray[index1],mArray[index2]);
						mArray[itemCount++].show();
						break;
					}
				}
			}catch(Exception e) {
				System.out.println("�п�J�Ʀr! ");
			}
			scanner.nextLine();
		}
	}
	
	public static void transposeMatrix() {
		while(true) {
			System.out.print("Index: ");
			String indexS = scanner.next();
			try {
				int index = Integer.parseInt(indexS);
				if (index >= itemCount || index < 0) {
					System.out.println("Index��J���~! �ثeIndex�q0��" + (itemCount-1));
				}
				else {
					mArray[itemCount] = SparseMatrix.Transpose(mArray[index]);
					mArray[itemCount++].show();
					break;
				}
			}catch(Exception e) {
				System.out.println("�п�J�Ʀr! ");
			}
			scanner.nextLine();	
		}
	}
	
	public static void cloneMatrix() {
		while (true) {
			System.out.print("Index: ");
			String indexS = scanner.next();
			try {
				int index = Integer.parseInt(indexS);
				if (index >= itemCount || index < 0) {
					System.out.println("Index��J���~! �ثeIndex�q0��" + (itemCount-1));
				}
				else {
					mArray[itemCount] = SparseMatrix.clone(mArray[index]);
					mArray[itemCount++].show();
					break;
				}
			}catch(Exception e) {
				System.out.println("�п�J�Ʀr! ");
			}
			scanner.nextLine();
		}
	}
	
	public static void readFile(String fileName) throws IOException {
		FileReader fr = null;
		BufferedReader bufIn = null;
		try {
			fr = new FileReader(fileName);
			bufIn = new BufferedReader(fr);
		} catch (Exception e) {
			System.out.println("File is not found.");
		}
		String str = null;
		
		while((str = bufIn.readLine())!= null) {
			//Read the file and write into mArray[][]
			int row = 0;
			String[][] arr = new String[10][10];
			while (str != null && !str.equals("") ) {
				if (arr.length <= row) {
					arr = Arrays.copyOf(arr, arr.length*2);
				}
				String[] strSplit = str.split("\\s+");
				arr[row] = strSplit;
				row++;
				str = bufIn.readLine();
			}
			
			//Write arr[][] into Term class object
			int count = 0;
			mArray[itemCount] = new SparseMatrix(row,arr[0].length);
			for (int i = 0; i < row; i++) {
				for (int j = 0; j < arr[i].length; j ++) {
					try {
						int value = Integer.parseInt(arr[i][j]);
						if (value != 0) {
							mArray[itemCount].addTerm(i, j, value);
							count++;
						}
					}
					catch (Exception e){
						System.out.println("Matrix format error!");
					}
				}
			}
			mArray[itemCount++].setTermValue(0, count);
			//System.out.println("round " + itemCount);
		}
		newItem = itemCount;
		fr.close();
	}
	
	

}
