package SparseMatrix.copy;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.WriteAbortedException;
import java.sql.Ref;
import java.util.Arrays;
import java.util.function.IntPredicate;

import javax.xml.crypto.dsig.spec.SignatureMethodParameterSpec;

public class SparseMatrix {
	private Term[] terms;
	private int itemCount;
	private int MAX_COL = 0;

	public SparseMatrix() {
	}

	public SparseMatrix(int r, int c) {
		itemCount = 0;
		terms = new Term[2];
		terms[itemCount] = new Term();
		terms[itemCount].row = r;
		terms[itemCount].col = c;
		terms[itemCount++].value = 0;
	}

	public SparseMatrix(int r, int c, int v) {
		itemCount = 0;
		terms = new Term[v + 1];
		terms[itemCount] = new Term();
		terms[itemCount].row = r;
		terms[itemCount].col = c;
		terms[itemCount++].value = v;
	}

	public void addTerm(int r, int c, int value) {
		if (terms.length <= itemCount)
			terms = Arrays.copyOf(terms, terms.length * 2);
		terms[itemCount] = new Term();
		terms[itemCount].row = r;
		terms[itemCount].col = c;
		terms[itemCount++].value = value;
	}

	public int getItemCount() {
		return itemCount;
	}

	public Term[] getTerms() {
		return terms;
	}
	
	public void setTerms(Term[] terms) {
		this.terms = terms;
	}

	public void setTermValue(int index, int value) {
		this.terms[index].value = value;
	}

	public void show() {
		int count = 1;
		for (int i = 0; i < terms[0].row; i++) {
			for (int j = 0; j < terms[0].col; j++) {
				if (count < terms[0].value + 1) {
					if (i == terms[count].row && j == terms[count].col) {
						System.out.printf("%5d", terms[count].value);
						count++;
					} else {
						System.out.printf("%5d", 0);
					}
				} else {
					System.out.printf("%5d", 0);
				}
			}
			System.out.println("");
		}
	}
	
	
	public void writeMatrix(String fileName) throws IOException {
		FileWriter fr = new FileWriter(fileName,true);
		BufferedWriter bfw = new BufferedWriter(fr,100);
		bfw.newLine();
		int count = 1;
		for (int i = 0; i < terms[0].row; i++) {
			for (int j = 0; j < terms[0].col; j++) {
				if (count < terms[0].value + 1) {
					if (i == terms[count].row && j == terms[count].col) {
						String term = String.format("%-5d",terms[count].value);
						bfw.write(term);
						//System.out.printf("%5d", terms[count].value);
						count++;
					} else {
						String term = String.format("%-5d",0);
						bfw.write(term);
						//System.out.printf("%5d", 0);
					}
				} else {
					String term = String.format("%-5d",0);
					bfw.write(term);
					//System.out.printf("%5d", 0);
				}
			}
			bfw.newLine();
			//System.out.println("");
		}
		bfw.newLine();
		bfw.flush();
		fr.close();
	}
	
	public static SparseMatrix clone(SparseMatrix m) {
		int r = m.getTerms()[0].row;
		int c = m.getTerms()[0].col;
		int v = m.getTerms()[0].value;

		SparseMatrix cloneMatrix = new SparseMatrix(r, c, v);
		for (int i = 1; i <= v; i++) {
			int rowClone = m.getTerms()[i].row;
			int colClone = m.getTerms()[i].col;
			int valClone = m.getTerms()[i].value;
			cloneMatrix.addTerm(rowClone, colClone, valClone);
		}
		return cloneMatrix;
	}

	public static SparseMatrix Transpose(SparseMatrix m) {
		SparseMatrix transMatrix = clone(m);
		transMatrix.getTerms()[0].row = m.getTerms()[0].col;
		transMatrix.getTerms()[0].col = m.getTerms()[0].row;
		int n = m.getTerms()[0].value;
		if (n > 0) {
			int currentb = 1;
			for (int i = 0; i < m.getTerms()[0].col; i++) {
				for (int j = 1; j <= n; j++) {
					if (m.getTerms()[j].col == i) {
						transMatrix.getTerms()[currentb].row = m.getTerms()[j].col;
						transMatrix.getTerms()[currentb].col = m.getTerms()[j].row;
						transMatrix.getTerms()[currentb].value = m.getTerms()[j].value;
						currentb++;
					}
				}
			}
		}
		return transMatrix;
	}

	public static SparseMatrix Add(SparseMatrix matrix1, SparseMatrix matrix2) {
		int row = matrix1.getTerms()[0].row;
		int col = matrix1.getTerms()[0].col;
		int value = 0;
		SparseMatrix sumMatrix = new SparseMatrix(row, col);
		int start = 1;
		for (int i = 0; i < row; i++) {

			for (int j = 0; j < col; j++) {
				int sum = 0;
				if (start <= matrix1.getTerms()[0].value) {
					if (i == matrix1.getTerms()[start].row && j == matrix1.getTerms()[start].col)
						sum += matrix1.getTerms()[start].value;
					if (i == matrix2.getTerms()[start].row && j == matrix2.getTerms()[start].col)
						sum += matrix2.getTerms()[start].value;
					if (sum != 0) {
						sumMatrix.addTerm(i, j, sum);
						start++;
						value++;
					}
				}
			}
		}

		sumMatrix.getTerms()[0].value = value;
		return sumMatrix;
	}

	private void findMAX_COL() {
		for (int i = 1; i < itemCount; i++) {
			if (this.terms[i].col > MAX_COL)
				this.MAX_COL = this.terms[i].col;
		}
		this.MAX_COL += 1;
	}

	public void FastTranspose() {
		// the transpose of terms is placed in b
		this.findMAX_COL();
		Term[] b = new Term[this.terms[0].value + 1];
		int count = 0;
		for (int i = 0; i < this.itemCount; i++) {
			b[count++] = new Term();
		}
		int[] rowTerms = new int[MAX_COL];
		int[] startingPos = new int[MAX_COL];
		int numCols = terms[0].col;
		int numTerms = terms[0].value;
		b[0].row = numCols;
		b[0].col = terms[0].row;
		b[0].value = numTerms;
		if (numTerms > 0) { // nonzero matrix
			for (int i = 0; i < MAX_COL; i++) {
				rowTerms[i] = 0;
			}
			//�����C�榳�X�ӫD�s����
			for (int i = 1; i <= numTerms; i++)
				rowTerms[terms[i].col]++;
			startingPos[0] = 1;
			//�����C��Ĥ@�ӫD�s�ȶ��ت�index
			for (int i = 1; i < MAX_COL; i++)
				startingPos[i] = startingPos[i - 1] + rowTerms[i - 1];
			
			for (int i = 1; i <= numTerms; i++) {
				int j = startingPos[terms[i].col]++;
				b[j].row = terms[i].col;
				b[j].col = terms[i].row;
				b[j].value = terms[i].value;
			}
		}
		terms = null;
		terms = b;

	}

	public static SparseMatrix mult(SparseMatrix matrix1, SparseMatrix matrix2) {
		// �N��ӯx�}���ê��}�C���x�}�ۭ��B��
		
		matrix1.addTerm(0, 0, 0);
		Term[] a = matrix1.getTerms();
		Term[] b = matrix2.getTerms();
		
		SparseMatrix newMatrix2 = clone(matrix2);
		newMatrix2.FastTranspose();
		newMatrix2.addTerm(0, 0, 0);
		
		Term[] newB = newMatrix2.getTerms();
		SparseMatrix resultMatrix = clone(matrix1);
		
		int i = 1, column, totalB = b[0].value, totalD = 0;
		int rowsA = a[0].row, colsA = a[0].col, totalA = a[0].value, colsB = b[0].col; // totalA�O�Ĥ@�ӯx�}�D�s�����Ӽ�
		int rowBegin = 1, row = a[1].row, sum = 0;
		if (colsA != b[0].row)
			return null;
		Term[] d = new Term[a[0].row * b[0].col + 1];
		d[totalD++] = new Term();
		// �]�w��ɪ��p
		a[totalA + 1].row = rowsA;
		newB[totalB + 1].row = colsB;
		newB[totalB + 1].col = 0;
		
		while (i <= totalA) {
			column = newB[1].row;
			int j = 1;
			while (j <= totalB + 1) {
				// a��row *= b��column
				if (a[i].row != row) {
					if (sum != 0) {
						d[totalD] = new Term();
						d[totalD].row = row;
						d[totalD].col = column;
						d[totalD++].value = sum;
						sum = 0;
					}
					i = rowBegin;
					while (newB[j].row == column)
						j++;
					column = newB[j].row;
				} else if (newB[j].row != column) {
					if (sum != 0) {
						d[totalD] = new Term();
						d[totalD].row = row;
						d[totalD].col = column;
						d[totalD++].value = sum;
						sum = 0;
					}
					i = rowBegin;
					column = newB[j].row;
				} else {
					if (a[i].col - newB[j].col < 0) { // go to next term in a
						i++;
					} else if (a[i].col - newB[j].col == 0) // add terms, go to next term in a and b
					{
						sum += (a[i++].value * newB[j++].value);
					} else // advance to next term in b
						j++;

				}
			}
				while (a[i].row == row)
					i++;
				
				rowBegin = i;
				row = a[i].row;
			} // end of for i <= totalA
		
			d[0].row = rowsA;
			d[0].col = colsB;
			d[0].value = totalD -1;
			
			resultMatrix.setTerms(d);
			return resultMatrix;

	}
	
	public static class Term {
		
		 int row;
		 int col;
		 int value;

		public Term() {
			
		}
		
		public int getCol() {
			return col;
		}
		
		public int getRow() {
			return row;
		}
		
		public int getValue() {
			return value;
		}
		
		public void setCol(int col) {
			this.col = col;
		}
		public void setRow(int row) {
			this.row = row;
		}
		public void setValue(int value) {
			this.value = value;
		}
	}


}
